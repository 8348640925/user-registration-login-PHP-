<?php
require_once __DIR__ . '/config.php';

if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$errors = [];
$name = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($name === '' || mb_strlen($name) < 2 || mb_strlen($name) > 80) {
        $errors[] = 'Name must be between 2 and 80 characters.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $errors[] = 'Enter a valid email address.';
    }
    $errors = array_merge($errors, password_problems($password));
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ? UNION SELECT id FROM admins WHERE email = ? LIMIT 1');
        $check->execute([$email, $email]);

        if ($check->fetch()) {
            $errors[] = 'An account with this email already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            try {
                $insert = $pdo->prepare('INSERT INTO users (name, email, password, last_login_at, login_count) VALUES (?, ?, ?, NOW(), 1)');
                $insert->execute([$name, $email, $hash]);
                $newId = (int)$pdo->lastInsertId();
                log_login($pdo, $newId, $email, 'user', 'success');

                session_regenerate_id(true);
                unset($_SESSION['admin_id']);
                $_SESSION['user_id'] = $newId;
                $_SESSION['user_name'] = $name;

                header('Location: dashboard.php');
                exit;
            } catch (PDOException $ex) {
                if ($ex->getCode() === '23000') {
                    $errors[] = 'An account with this email already exists.';
                } else {
                    throw $ex;
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create account | User Portal</title>
    <link rel="icon" type="image/png" href="assets/logo.png">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<main class="auth-wrap">
    <section class="auth-card">
        <img class="auth-logo" src="assets/logo.png" alt="Registration &amp; Login System">
        <h1>Create your account</h1>
        <p class="subtext">Register to access your personal dashboard.</p>

        <?php if ($errors): ?>
            <div class="alert error" role="alert">
                <?php foreach ($errors as $error): ?><p><?= e($error) ?></p><?php endforeach; ?>
            </div>
        <?php endif; ?>

        <form method="post" action="register.php" novalidate>
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <label for="name">Full name</label>
            <input id="name" name="name" type="text" autocomplete="name" value="<?= e($name) ?>" placeholder="Your name" required>

            <label for="email">Email address</label>
            <input id="email" name="email" type="email" autocomplete="email" value="<?= e($email) ?>" placeholder="you@example.com" required>

            <label for="password">Password</label>
            <input id="password" name="password" type="password" autocomplete="new-password" placeholder="Create a strong password" required>
            <p class="hint">Use 8+ characters with uppercase, lowercase, a number and a symbol. Avoid sequences like 12345678 or abcd.</p>

            <label for="confirm_password">Confirm password</label>
            <input id="confirm_password" name="confirm_password" type="password" autocomplete="new-password" placeholder="Enter password again" required>

            <button type="submit">Create account</button>
        </form>
        <p class="switch">Already have an account? <a href="login.php">Log in</a></p>
    </section>
</main>
</body>
</html>
