<?php
require_once __DIR__ . '/../config.php';
require_admin();

$allowed = ['success', 'failed', 'blocked'];
$status = $_GET['status'] ?? '';
if (!in_array($status, $allowed, true)) {
    $status = '';
}

if ($status !== '') {
    $stmt = $pdo->prepare('SELECT * FROM login_logs WHERE status = ? ORDER BY id DESC LIMIT 300');
    $stmt->execute([$status]);
} else {
    $stmt = $pdo->query('SELECT * FROM login_logs ORDER BY id DESC LIMIT 300');
}
$logs = $stmt->fetchAll();

$page_title = 'Login activity';
$active = 'logs';
require __DIR__ . '/_header.php';
?>
<h1>Login activity</h1>
<p class="subtext">The latest 300 login attempts by customers and the admin.</p>

<div class="filter-row">
    <a class="chip <?= $status === '' ? 'on' : '' ?>" href="logs.php">All</a>
    <a class="chip <?= $status === 'success' ? 'on' : '' ?>" href="logs.php?status=success">Successful</a>
    <a class="chip <?= $status === 'failed' ? 'on' : '' ?>" href="logs.php?status=failed">Failed</a>
    <a class="chip <?= $status === 'blocked' ? 'on' : '' ?>" href="logs.php?status=blocked">Blocked users</a>
</div>

<div class="table-wrap">
<table>
    <thead><tr><th>Time</th><th>Email</th><th>Role</th><th>Result</th><th>IP address</th><th>Device</th></tr></thead>
    <tbody>
    <?php if (!$logs): ?>
        <tr><td colspan="6" class="empty">No login activity yet.</td></tr>
    <?php endif; ?>
    <?php foreach ($logs as $l): ?>
        <tr>
            <td><?= e(format_dt($l['created_at'])) ?></td>
            <td><?= e($l['email']) ?></td>
            <td><?= $l['role'] === 'admin' ? 'Admin' : 'Customer' ?></td>
            <td><span class="badge badge-<?= e($l['status']) ?>"><?= e(ucfirst($l['status'])) ?></span></td>
            <td><?= e($l['ip_address']) ?></td>
            <td class="ua" title="<?= e($l['user_agent']) ?>"><?= e(mb_strimwidth($l['user_agent'], 0, 48, '…')) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
