<?php
require_once __DIR__ . '/../config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}
verify_csrf();

$id = (int)($_POST['user_id'] ?? 0);
$action = $_POST['action'] ?? '';
$q = trim($_POST['q'] ?? '');

$stmt = $pdo->prepare('SELECT id, name FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$id]);
$user = $stmt->fetch();

if (!$user) {
    flash_set('error', 'User not found.');
} elseif ($action === 'block') {
    $pdo->prepare('UPDATE users SET is_blocked = 1 WHERE id = ?')->execute([$id]);
    flash_set('success', $user['name'] . ' has been blocked and can no longer log in.');
} elseif ($action === 'unblock') {
    $pdo->prepare('UPDATE users SET is_blocked = 0 WHERE id = ?')->execute([$id]);
    flash_set('success', $user['name'] . ' has been unblocked.');
} elseif ($action === 'delete') {
    $pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$id]);
    flash_set('success', $user['name'] . ' has been deleted.');
} else {
    flash_set('error', 'Unknown action.');
}

header('Location: index.php' . ($q !== '' ? '?q=' . urlencode($q) : ''));
exit;
