<?php
if (!function_exists('e')) { http_response_code(403); exit; }
// Expects: $page_title (string), $active ('users' | 'logs' | 'settings')
$flash = flash_get();
$nav = ['users' => ['index.php', 'Users'], 'logs' => ['logs.php', 'Login activity'], 'settings' => ['settings.php', 'Admin settings']];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($page_title) ?> | Admin</title>
    <link rel="icon" type="image/png" href="../assets/logo.png">
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<header class="topbar">
    <a class="wordmark" href="index.php"><img class="logo-sm" src="../assets/logo.png" alt="">User<span>Portal</span> Admin</a>
    <nav class="admin-nav">
        <?php foreach ($nav as $key => [$href, $label]): ?>
            <a href="<?= e($href) ?>" class="<?= $active === $key ? 'active' : '' ?>"><?= e($label) ?></a>
        <?php endforeach; ?>
    </nav>
    <form method="post" action="../logout.php">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <button class="logout" type="submit">Log out</button>
    </form>
</header>
<main class="admin-wrap">
    <?php if ($flash): ?>
        <div class="alert <?= $flash['type'] === 'success' ? 'success' : 'error' ?>" role="status"><p><?= e($flash['msg']) ?></p></div>
    <?php endif; ?>
