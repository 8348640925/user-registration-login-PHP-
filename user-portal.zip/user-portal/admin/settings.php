<?php
require_once __DIR__ . '/../config.php';
require_admin();

$stmt = $pdo->prepare('SELECT id, email, password FROM admins WHERE id = ? LIMIT 1');
$stmt->execute([$_SESSION['admin_id']]);
$admin = $stmt->fetch();
if (!$admin) {
    $_SESSION = [];
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$errors = [];
$newEmail = $admin['email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $current = $_POST['current_password'] ?? '';
    $newEmail = strtolower(trim($_POST['email'] ?? ''));
    $newPass = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (!password_verify($current, $admin['password'])) {
        $errors[] = 'Current password is incorrect.';
    }
    if ($newEmail === '' || strlen($newEmail) > 190 || strpos($newEmail, '@') === false || preg_match('/\s/', $newEmail)) {
        $errors[] = 'Enter a valid admin email.';
    } else {
        $dup = $pdo->prepare('SELECT id FROM users WHERE email = ? UNION SELECT id FROM admins WHERE email = ? AND id <> ? LIMIT 1');
        $dup->execute([$newEmail, $newEmail, $admin['id']]);
        if ($dup->fetch()) {
            $errors[] = 'That email is already used by another account.';
        }
    }
    if ($newPass !== '') {
        $errors = array_merge($errors, password_problems($newPass));
        if ($newPass !== $confirm) {
            $errors[] = 'New passwords do not match.';
        }
    }

    if (!$errors) {
        $hash = $newPass !== '' ? password_hash($newPass, PASSWORD_DEFAULT) : $admin['password'];
        $pdo->prepare('UPDATE admins SET email = ?, password = ? WHERE id = ?')->execute([$newEmail, $hash, $admin['id']]);
        flash_set('success', 'Admin login details updated. Use them the next time you log in.');
        header('Location: settings.php');
        exit;
    }
}

$page_title = 'Admin settings';
$active = 'settings';
require __DIR__ . '/_header.php';
?>
<h1>Admin settings</h1>
<p class="subtext">Change the email and password used to log in as admin.</p>

<section class="profile-card settings-card">
    <?php if ($errors): ?>
        <div class="alert error" role="alert"><?php foreach ($errors as $err): ?><p><?= e($err) ?></p><?php endforeach; ?></div>
    <?php endif; ?>
    <form method="post" action="settings.php" autocomplete="off">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

        <label for="email">Admin email</label>
        <input id="email" name="email" type="text" value="<?= e($newEmail) ?>" required>

        <label for="new_password">New password <small>(leave empty to keep the current one)</small></label>
        <input id="new_password" name="new_password" type="password" autocomplete="new-password" placeholder="Create a strong password">
        <p class="hint">Use 8+ characters with uppercase, lowercase, a number and a symbol. Avoid sequences like 12345678 or abcd.</p>

        <label for="confirm_password">Confirm new password</label>
        <input id="confirm_password" name="confirm_password" type="password" autocomplete="new-password">

        <label for="current_password">Current password <small>(required to save)</small></label>
        <input id="current_password" name="current_password" type="password" autocomplete="current-password" required>

        <button class="btn btn-primary" type="submit">Save changes</button>
    </form>
</section>
<?php require __DIR__ . '/_footer.php'; ?>
