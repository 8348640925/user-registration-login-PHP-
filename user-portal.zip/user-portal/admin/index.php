<?php
require_once __DIR__ . '/../config.php';
require_admin();

$q = trim($_GET['q'] ?? '');

$stats = $pdo->query("SELECT
    (SELECT COUNT(*) FROM users) AS total,
    (SELECT COUNT(*) FROM users WHERE is_blocked = 0) AS active,
    (SELECT COUNT(*) FROM users WHERE is_blocked = 1) AS blocked,
    (SELECT COUNT(*) FROM login_logs WHERE status = 'success' AND DATE(created_at) = CURDATE()) AS logins_today,
    (SELECT COUNT(*) FROM login_logs WHERE status <> 'success' AND DATE(created_at) = CURDATE()) AS failed_today
")->fetch();

if ($q !== '') {
    $like = '%' . addcslashes($q, '%_\\') . '%';
    $stmt = $pdo->prepare('SELECT id, name, email, is_blocked, last_login_at, login_count, created_at FROM users WHERE name LIKE ? OR email LIKE ? ORDER BY id DESC LIMIT 500');
    $stmt->execute([$like, $like]);
} else {
    $stmt = $pdo->query('SELECT id, name, email, is_blocked, last_login_at, login_count, created_at FROM users ORDER BY id DESC LIMIT 500');
}
$users = $stmt->fetchAll();

$page_title = 'Users';
$active = 'users';
require __DIR__ . '/_header.php';
?>
<h1>Users</h1>
<p class="subtext">Block or unblock customers and see when they last logged in.</p>

<div class="stat-grid">
    <div class="stat"><strong><?= (int)$stats['total'] ?></strong><span>Total users</span></div>
    <div class="stat"><strong><?= (int)$stats['active'] ?></strong><span>Active</span></div>
    <div class="stat"><strong><?= (int)$stats['blocked'] ?></strong><span>Blocked</span></div>
    <div class="stat"><strong><?= (int)$stats['logins_today'] ?></strong><span>Logins today</span></div>
    <div class="stat"><strong><?= (int)$stats['failed_today'] ?></strong><span>Failed or blocked today</span></div>
</div>

<form method="get" class="search-bar">
    <input type="text" name="q" value="<?= e($q) ?>" placeholder="Search by name or email" aria-label="Search users">
    <button class="btn" type="submit">Search</button>
    <?php if ($q !== ''): ?><a class="btn btn-ghost" href="index.php">Clear</a><?php endif; ?>
</form>

<div class="table-wrap">
<table>
    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Status</th><th>Last login</th><th>Logins</th><th>Registered</th><th>Actions</th></tr></thead>
    <tbody>
    <?php if (!$users): ?>
        <tr><td colspan="8" class="empty">No users found.</td></tr>
    <?php endif; ?>
    <?php foreach ($users as $u): ?>
        <tr>
            <td><?= (int)$u['id'] ?></td>
            <td><?= e($u['name']) ?></td>
            <td><?= e($u['email']) ?></td>
            <td><span class="badge <?= $u['is_blocked'] ? 'badge-blocked' : 'badge-active' ?>"><?= $u['is_blocked'] ? 'Blocked' : 'Active' ?></span></td>
            <td><?= e(format_dt($u['last_login_at'])) ?></td>
            <td><?= (int)$u['login_count'] ?></td>
            <td><?= e(format_dt($u['created_at'])) ?></td>
            <td class="actions">
                <form method="post" action="action.php">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                    <input type="hidden" name="q" value="<?= e($q) ?>">
                    <?php if ($u['is_blocked']): ?>
                        <button class="btn btn-ok" name="action" value="unblock" type="submit">Unblock</button>
                    <?php else: ?>
                        <button class="btn btn-warn" name="action" value="block" type="submit">Block</button>
                    <?php endif; ?>
                </form>
                <form method="post" action="action.php" onsubmit="return confirm('Delete this user permanently?');">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                    <input type="hidden" name="q" value="<?= e($q) ?>">
                    <button class="btn btn-danger" name="action" value="delete" type="submit">Delete</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
