<?php
require_once __DIR__ . '/config.php';

no_cache();

if (!is_logged_in()) {
    header('Location: login.php');
    exit;
}

$stmt = $pdo->prepare('SELECT name, email, created_at, is_blocked, last_login_at FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

if (!$user || (int)$user['is_blocked'] === 1) {
    $_SESSION = [];
    session_destroy();
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | User Portal</title>
    <link rel="icon" type="image/png" href="assets/logo.png">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
    <a class="wordmark" href="dashboard.php"><img class="logo-sm" src="assets/logo.png" alt="">User<span>Portal</span></a>
    <form method="post" action="logout.php">
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <button class="logout" type="submit">Log out</button>
    </form>
</header>
<main class="dashboard">
    <section class="welcome-panel">
        <p class="eyebrow">YOUR ACCOUNT</p>
        <h1>Hello, <?= e($user['name']) ?>!</h1>
        <p class="subtext">You have successfully logged in to your dashboard.</p>
    </section>
    <section class="profile-card">
        <h2>Profile information</h2>
        <div class="profile-row"><span>Full name</span><strong><?= e($user['name']) ?></strong></div>
        <div class="profile-row"><span>Email address</span><strong><?= e($user['email']) ?></strong></div>
        <div class="profile-row"><span>Last login</span><strong><?= e(format_dt($user['last_login_at'])) ?></strong></div>
        <div class="profile-row"><span>Member since</span><strong><?= e(date('d M Y', strtotime($user['created_at']))) ?></strong></div>
    </section>
</main>
</body>
</html>
