<?php
require_once __DIR__ . '/config.php';
if (is_admin()) {
    header('Location: admin/index.php');
    exit;
}
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}
header('Location: login.php');
exit;
