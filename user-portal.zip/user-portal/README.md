# User Portal – Registration & Login (PHP + MySQL)

Works with XAMPP on Windows, macOS and Linux (PHP 7.4 or newer).

## Run it in 3 steps
1. Open the **XAMPP Control Panel** and click **Start** next to **Apache** and **MySQL**.
2. Copy the `user-portal` folder into the XAMPP web folder:
   - Windows: `C:\xampp\htdocs\user-portal`
   - macOS: `/Applications/XAMPP/htdocs/user-portal`
   - Linux: `/opt/lampp/htdocs/user-portal`
3. Open **http://localhost/user-portal/** in your browser.

The database (`user_auth`), all tables and the admin account are created automatically on the first page load.
Importing `database.sql` in phpMyAdmin is optional; it does the same thing.

## Admin panel
- Log in on the normal login page with the admin email and password (default: `admin@123` / `admin123`).
- Change them under **Admin settings**. New passwords must be strong (8+ characters, upper and lower case, a number and a symbol; no sequences like 1234 or abcd).
- **Users:** search, block, unblock, delete, last login time, login count.
- **Login activity:** every success, failure and blocked attempt with time, IP and device.

## Common XAMPP problems
| Problem | Fix |
|---|---|
| "Cannot connect to MySQL" | Start MySQL in the XAMPP Control Panel. |
| MySQL uses port 3307 | Set `$db_port = 3307;` in `config.php`. |
| You set a MySQL root password | Put it in `$db_pass` in `config.php`. |
| Apache will not start (port 80 busy) | Use another port in XAMPP, then open `http://localhost:8080/user-portal/`. |
| Blank page or `pdo_mysql` message | In XAMPP: Apache > Config > php.ini, enable `extension=pdo_mysql`, restart Apache. |
| Page shows 404 | Check the folder name: it must be `user-portal` directly inside `htdocs`. |

## Files
- `index.php` – sends visitors to the dashboard, admin panel or login
- `login.php`, `register.php`, `dashboard.php`, `logout.php`
- `config.php` – database settings, session, CSRF, auto-setup, helpers
- `admin/` – `index.php` (users), `logs.php`, `settings.php`, `action.php`
- `assets/` – `style.css`, `logo.png`
- `database.sql` – optional manual import

Before putting this on a real server: set `$debug = false;` and a MySQL password in `config.php`, and change the admin password.
