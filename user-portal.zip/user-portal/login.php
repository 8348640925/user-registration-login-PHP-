<?php
require_once __DIR__ . '/config.php';

if (is_admin()) {
    header('Location: admin/index.php');
    exit;
}
if (is_logged_in()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    // Too many recent failures from this address?
    $recent = $pdo->prepare("SELECT COUNT(*) FROM login_logs WHERE status = 'failed' AND ip_address = ? AND created_at > (NOW() - INTERVAL 5 MINUTE)");
    $recent->execute([client_ip()]);

    if ($email === '' || strlen($email) > 190 || $password === '') {
        $error = 'Enter your email and password.';
    } elseif ((int)$recent->fetchColumn() >= 5) {
        $error = 'Too many failed attempts. Wait a few minutes and try again.';
    } else {
        // Cached dummy hash keeps response time similar for unknown emails.
        $_SESSION['dummy_hash'] = $_SESSION['dummy_hash'] ?? password_hash('not-a-real-password', PASSWORD_DEFAULT);

        $stmt = $pdo->prepare('SELECT id, email, password FROM admins WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin) {
            if (password_verify($password, $admin['password'])) {
                session_regenerate_id(true);
                unset($_SESSION['user_id'], $_SESSION['user_name']);
                $_SESSION['admin_id'] = (int)$admin['id'];
                log_login($pdo, null, $email, 'admin', 'success');
                header('Location: admin/index.php');
                exit;
            }
            log_login($pdo, null, $email, 'admin', 'failed');
            $error = 'Incorrect email or password.';
        } else {
            $stmt = $pdo->prepare('SELECT id, name, email, password, is_blocked FROM users WHERE email = ? LIMIT 1');
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            $hash = $user['password'] ?? $_SESSION['dummy_hash'];
            $ok = password_verify($password, $hash) && $user;

            if ($ok && (int)$user['is_blocked'] === 1) {
                log_login($pdo, (int)$user['id'], $email, 'user', 'blocked');
                $error = 'Your account has been blocked. Contact the administrator.';
            } elseif ($ok) {
                if (password_needs_rehash($hash, PASSWORD_DEFAULT)) {
                    $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')
                        ->execute([password_hash($password, PASSWORD_DEFAULT), $user['id']]);
                }
                $pdo->prepare('UPDATE users SET last_login_at = NOW(), login_count = login_count + 1 WHERE id = ?')
                    ->execute([$user['id']]);
                log_login($pdo, (int)$user['id'], $email, 'user', 'success');

                session_regenerate_id(true);
                unset($_SESSION['admin_id']);
                $_SESSION['user_id'] = (int)$user['id'];
                $_SESSION['user_name'] = $user['name'];
                header('Location: dashboard.php');
                exit;
            } else {
                log_login($pdo, $user ? (int)$user['id'] : null, $email, 'user', 'failed');
                $error = 'Incorrect email or password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in | User Portal</title>
    <link rel="icon" type="image/png" href="assets/logo.png">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<main class="auth-wrap">
    <section class="auth-card">
        <img class="auth-logo" src="assets/logo.png" alt="Registration &amp; Login System">
        <h1>Welcome back</h1>
        <p class="subtext">Log in to continue to your account.</p>

        <?php if ($error): ?>
            <div class="alert error" role="alert"><p><?= e($error) ?></p></div>
        <?php endif; ?>

        <form method="post" action="login.php">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
            <label for="email">Email address</label>
            <input id="email" name="email" type="email" autocomplete="email" value="<?= e($email) ?>" placeholder="you@example.com" required>

            <label for="password">Password</label>
            <input id="password" name="password" type="password" autocomplete="current-password" placeholder="Your password" required>

            <button type="submit">Log in</button>
        </form>
        <p class="switch">New here? <a href="register.php">Create an account</a></p>
    </section>
</main>
</body>
</html>
